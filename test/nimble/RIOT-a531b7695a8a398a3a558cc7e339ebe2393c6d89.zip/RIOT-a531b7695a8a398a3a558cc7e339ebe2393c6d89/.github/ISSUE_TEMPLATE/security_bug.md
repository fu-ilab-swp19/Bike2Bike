---
name: 'Security Bug report'
about: |
    Don't use the issue tracker for this! Please write an e-mail to
    security@riot-os.org. The button was just added to advertise this message.
---

# DON'T USE THE ISSUE TRACKER FOR THIS!
<!--
Please write an e-mail to security@riot-os.org. The button was just added to
advertise this message!
-->
