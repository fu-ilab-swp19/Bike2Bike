---
name: Feature Request
about: Ask for missing features or improvements

---

#### Description
<!-- Please describe your use case, why you need this feature and why this
feature is important for RIOT. -->

### Useful links
<!-- Please include links to any documentation that you think is useful. -->

<!-- Thanks for contributing! -->
