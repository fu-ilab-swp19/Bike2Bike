/*
 * Copyright (C) 2018 Gunar Schorcht
 *
 * This file is subject to the terms and conditions of the GNU Lesser
 * General Public License v2.1. See the file LICENSE in the top level
 * directory for more details.
 */

/**
 * @ingroup     boards_esp32_olimex-esp32-evb
 * @brief       Board specific definitions for Olimex ESP32-EVB (ESP32-GATEWAY)
 *
 * This configuration is for the Olimex ESP32-EVB, but can also be used
 * for the Olimex ESP32-GATEWAY. To use this board definition with Olimex
 * ESP32-GATEWAY, add
 * ```
 * USEMODULE += olimex_esp32_gateway
 * ```
 * to the makefile of the application to use the according default board
 * configuration.
 *
 * For detailed information about the configuration of ESP32 boards, see
 * section \ref esp32_comm_periph "Common Peripherals".
 *
 * @note
 * Most definitions can be overridden by an \ref esp32_app_spec_conf
 * "application-specific board configuration".
 *
 * @author      Gunar Schorcht <gunar@schorcht.net>
 * @file
 * @{
 */

#ifndef BOARD_H
#define BOARD_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @name    Button pin definitions
 * @{
 */
#define BUTTON0_PIN     GPIO34
/** @} */

/**
 * @name    LED (on-board) configuration
 *
 * Olimex ESP32-GATEWAY has an on-board LED.
 * @{
 */
#if MODULE_OLIMEX_ESP32_GATEWAY
#define LED0_PIN        GPIO33
#define LED0_ACTIVE     (1)     /**< LED is high active */
#endif
/** @} */

/**
 * @name SD-Card interface configuration
 *
 * SD-Card interface uses SPI_DEV(1) on this board.
 *
 * @note On Olimex ESP32-EVB, the CD/CS pin is not connected and
 * simply pulled-up. Therefore, SPI bus mode is not available and the card
 * interface can be used only in 1-bit SD bus mode. That is, SPI SD-Card
 * is not working. On Olimex ESP32-GATEWAY, the CD/CS pin is connected to
 * GPIO13. The SPI SD-Card driver should work on this board.
 * @{
 */
#if (MODULE_SDCARD_SPI && MODULE_OLIMEX_ESP32_GATEWAY) || DOXYGEN
#define SDCARD_SPI_PARAM_SPI        SPI_DEV(0)
#define SDCARD_SPI_PARAM_CS         GPIO13
#define SDCARD_SPI_PARAM_CLK        SPI0_SCK
#define SDCARD_SPI_PARAM_MOSI       SPI0_MOSI
#define SDCARD_SPI_PARAM_MISO       SPI0_MISO
#define SDCARD_SPI_PARAM_POWER      GPIO_UNDEF
#endif
/** @} */

/**
 * @name    ESP32 Ethernet (EMAC) configuration
 * @{
 */
#if MODULE_ESP_ETH || DOXYGEN
#define EMAC_PHY_LAN8720        1                   /**< LAN8710 used as PHY interface */
#define EMAC_PHY_ADDRESS        0                   /**< PHY0 used as base address */
#define EMAC_PHY_SMI_MDC_PIN    23                  /**< SMI MDC pin */
#define EMAC_PHY_SMI_MDIO_PIN   18                  /**< SMI MDC pin */
#define EMAC_PHY_CLOCK_MODE     ETH_CLOCK_GPIO0_IN  /**< external 50 MHz clock */
#define EMAC_PHY_POWER_PIN      GPIO_UNDEF          /**< power enable pin not used */
#endif
/** @} */

/* include common board definitions as last step */
#include "board_common.h"

#ifdef __cplusplus
} /* end extern "C" */
#endif

#endif /* BOARD_H */
/** @} */
