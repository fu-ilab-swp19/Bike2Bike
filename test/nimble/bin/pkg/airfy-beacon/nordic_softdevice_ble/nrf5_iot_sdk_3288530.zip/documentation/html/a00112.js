var a00112 =
[
    [ "length", "a00112.html#ae5314a58ecf69d4576a0955dd3cda630", null ],
    [ "number", "a00112.html#ae7c4379b2c23cb6844486dbb69d513c5", null ],
    [ "p_data", "a00112.html#a13184dd24b254299bdf667bc4c5e5ec9", null ]
];