var a00119 =
[
    [ "current_value_sec", "a00119.html#ab0c40b0b95db2943daae94ecf0b5cf3b", null ],
    [ "is_timer_running", "a00119.html#a559d61372dbbaf3123374a9702daec48", null ],
    [ "timeout_handler", "a00119.html#aa63cb9a780551b0ffc7ba8c5275abfd2", null ]
];