var a00040 =
[
    [ "Server", "a00056.html", [
      [ "Common module dependency and usage", "a00056.html#iot_sdk_app_dtls_server_module_usage", null ],
      [ "Setup", "a00056.html#iot_sdk_app_dtls_server_setup", null ],
      [ "Testing", "a00056.html#iot_sdk_app_dtls_server_test", null ],
      [ "Known Issues", "a00056.html#iot_sdk_app_dtls_server_known_issues", null ],
      [ "Troubleshooting Guide", "a00056.html#iot_sdk_app_dtls_server_tbg", null ]
    ] ],
    [ "Client", "a00055.html", [
      [ "Common module dependency and usage", "a00055.html#iot_sdk_app_dtls_client_module_usage", null ],
      [ "Setup", "a00055.html#iot_sdk_app_dtls_client_setup", null ],
      [ "Testing", "a00055.html#iot_sdk_app_dtls_client_test", null ],
      [ "Known Issues", "a00055.html#iot_sdk_app_dtls_client_known_issues", null ],
      [ "Troubleshooting Guide", "a00055.html#iot_sdk_app_dtls_client_tbg", null ]
    ] ]
];