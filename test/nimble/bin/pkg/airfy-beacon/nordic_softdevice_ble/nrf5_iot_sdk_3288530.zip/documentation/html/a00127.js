var a00127 =
[
    [ "s6_addr", "a00127.html#aa1d600770ac35faa253a53aecd9b3786", null ]
];