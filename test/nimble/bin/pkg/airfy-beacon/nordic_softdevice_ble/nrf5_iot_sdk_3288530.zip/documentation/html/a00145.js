var a00145 =
[
    [ "application_type", "a00145.html#a4b109d8ad96de7ec4f48a918e3eb8464", null ],
    [ "current_value", "a00145.html#a821f785665a19f0399f0dcd9a5f65abf", null ],
    [ "max_measured_value", "a00145.html#a262a7a71c3a39847fff22591fe2497c4", null ],
    [ "max_range_value", "a00145.html#a4d7f93da6eeb72fb4389c3fc121c4a0b", null ],
    [ "min_measured_value", "a00145.html#add6548ff945db7d1e4b1767337628392", null ],
    [ "min_range_value", "a00145.html#a8f798b60cef691c5f158b87bd0c0c94d", null ],
    [ "operations", "a00145.html#abcf9734c66d9ef187adce1036bbdaa52", null ],
    [ "proto", "a00145.html#a12c2c3b38bced0085627660ec93e4ed3", null ],
    [ "resource_ids", "a00145.html#ac2326102654247d7895722c4d8e2e327", null ],
    [ "sensor_type", "a00145.html#ab38549a9f5b971f8021f05acacad514e", null ]
];