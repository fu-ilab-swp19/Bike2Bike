var a00091 =
[
    [ "License for Nordic components", "a00091.html#nordic_license", [
      [ "SDK license", "a00091.html#sdk_license", null ],
      [ "SoftDevice license", "a00091.html#sd_license", null ]
    ] ],
    [ "Licenses for third party components", "a00091.html#third_party_licenses", [
      [ "lwIP license", "a00091.html#lwip_license", null ],
      [ "mbedTLS license", "a00091.html#mbedtls_license", null ]
    ] ],
    [ "SDK License Agreement", "a00076.html", null ]
];