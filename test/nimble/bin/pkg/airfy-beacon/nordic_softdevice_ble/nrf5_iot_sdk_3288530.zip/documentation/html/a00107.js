var a00107 =
[
    [ "code", "a00107.html#a874558f4f1654df1acb43a2661b7cdd9", null ],
    [ "id", "a00107.html#ae32d530741e1f65d506ffe555193527d", null ],
    [ "port", "a00107.html#a14e53df4f82f1c950fbe6ca33f60c90c", null ],
    [ "response_callback", "a00107.html#aa4addf972e495f641cd6a746061b5829", null ],
    [ "token", "a00107.html#acecb1a08333ae1f7e355f2773b09fc52", null ],
    [ "token_len", "a00107.html#adc81b6239880e13ca91c2e05d3ef7996", null ],
    [ "type", "a00107.html#a7289fd6252f6ef17f7249d671fe47434", null ]
];