var a00108 =
[
    [ "code", "a00108.html#ac81145051ac12983129fe1ce9e96cb0c", null ],
    [ "id", "a00108.html#aada9d90ec6a64a4f0dc3b250aa45aa5c", null ],
    [ "token_len", "a00108.html#adc7ef64f03712a5c162dbc5d928f8212", null ],
    [ "type", "a00108.html#acf5e3a09a21d7347bcc0ab49fd1556e6", null ],
    [ "version", "a00108.html#ae1edaaa1d09c41829815ce4f01e9b464", null ]
];