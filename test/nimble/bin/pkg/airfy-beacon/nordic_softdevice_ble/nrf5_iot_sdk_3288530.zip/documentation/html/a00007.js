var a00007 =
[
    [ "BLE Commissioning Profile", "a00005.html", [
      [ "Configuration", "a00005.html#commissioning_profile_conf", [
        [ "Roles", "a00005.html#commissioning_profile_roles", null ],
        [ "Role/service relationships", "a00005.html#commissioning_profile_role_service", null ]
      ] ],
      [ "TTP role requirements", "a00005.html#commissioning_profile_updater_role_req", [
        [ "General error handling", "a00005.html#commissioning_profile_err_handling", null ],
        [ "Configuration procedure", "a00005.html#commissioning_profile_procedure", null ]
      ] ],
      [ "Security considerations", "a00005.html#security_considerations", null ]
    ] ],
    [ "BLE Node Configuration Service", "a00006.html", [
      [ "Proprietary service UUID", "a00006.html#commissioning_srv_number", null ],
      [ "Service characteristics", "a00006.html#commissioning_srv_char", [
        [ "Commissioning SSID", "a00006.html#commissioning_srv_char_ssid", null ],
        [ "Commissioning Keys Store", "a00006.html#commissioning_srv_char_keys", null ],
        [ "Commissioning Control Point", "a00006.html#commissioning_srv_char_cp", null ]
      ] ]
    ] ]
];