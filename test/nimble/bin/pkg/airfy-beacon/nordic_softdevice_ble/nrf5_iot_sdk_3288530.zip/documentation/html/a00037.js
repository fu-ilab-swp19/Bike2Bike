var a00037 =
[
    [ "CoAP", "a00031.html", "a00031" ],
    [ "MQTT", "a00034.html", "a00034" ]
];