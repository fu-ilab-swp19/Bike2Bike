var a00136 =
[
    [ "code", "a00136.html#ae1d72cd59a2951bc66f8a26ece78dd3e", null ],
    [ "p_msg", "a00136.html#aba7a3e0d391cc4423c8a55365cb48b9b", null ],
    [ "size_transfered", "a00136.html#aa65b4662eb625cba6f1eb623221ddc7d", null ]
];