var a00042 =
[
    [ "MQTT Client - Publisher", "a00063.html", [
      [ "Common Modules Dependency and Usage", "a00063.html#iot_sdk_app_mqtt_publisher_module_usage", null ],
      [ "Setup", "a00063.html#iot_sdk_app_mqtt_publisher_setup", [
        [ "LED assignments", "a00063.html#iot_sdk_app_mqtt_publisher_setup_led", null ],
        [ "Button assignments", "a00063.html#iot_sdk_app_mqtt_publisher_setup_button", null ],
        [ "MQTT Broker Setup", "a00063.html#iot_sdk_app_mqtt_broker_setup_publisher", null ],
        [ "MQTT Subscriber setup", "a00063.html#iot_sdk_app_mqtt_subsciber_setup_2", null ]
      ] ],
      [ "Testing", "a00063.html#iot_sdk_app_mqtt_publisher_test", null ]
    ] ],
    [ "MQTT Client - Subscriber", "a00064.html", [
      [ "Common Modules Dependency and Usage", "a00064.html#iot_sdk_app_mqtt_subscriber_module_usage", null ],
      [ "Setup", "a00064.html#iot_sdk_app_mqtt_subscriber_setup", [
        [ "LED assignments", "a00064.html#iot_sdk_app_mqtt_subscriber_setup_led", null ],
        [ "Button assignments", "a00064.html#iot_sdk_app_mqtt_subscriber_setup_button", null ],
        [ "MQTT Broker Setup", "a00064.html#iot_sdk_app_mqtt_broker_setup_subscriber", null ],
        [ "MQTT Publisher setup", "a00064.html#iot_sdk_app_mqtt_publisher_setup_2", null ]
      ] ],
      [ "Testing", "a00064.html#iot_sdk_app_mqtt_subscriber_test", null ]
    ] ]
];