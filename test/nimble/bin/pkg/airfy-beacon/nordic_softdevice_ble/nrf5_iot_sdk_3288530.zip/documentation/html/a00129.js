var a00129 =
[
    [ "compression_flag", "a00129.html#ac698c1a4e92b32c76aeb32d294597239", null ],
    [ "context_id", "a00129.html#ab4b9f418db1963afdcb7dd5895ddbb4b", null ],
    [ "prefix", "a00129.html#a6b2efab0f3511964ab3b21dafcb758aa", null ],
    [ "prefix_len", "a00129.html#a442a4472d16b021426d9bb80abad05ee", null ]
];