var a00131 =
[
    [ "application", "a00131.html#a20d7be9ce842a96983c3b7ea1485bd16", null ],
    [ "bootloader", "a00131.html#abd7ca3e95e5e19ca7eb1d70b4f060c14", null ],
    [ "softdevice", "a00131.html#ac43e09410ba72045b99c7b2cb73afafa", null ]
];