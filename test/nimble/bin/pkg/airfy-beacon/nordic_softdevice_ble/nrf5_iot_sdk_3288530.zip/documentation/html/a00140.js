var a00140 =
[
    [ "block_size", "a00140.html#a368deba5d9a2f47a4a63daefa1f4a632", null ],
    [ "next_retr", "a00140.html#a1df2c59c05e7d52b18ba689e30e7d1c8", null ]
];