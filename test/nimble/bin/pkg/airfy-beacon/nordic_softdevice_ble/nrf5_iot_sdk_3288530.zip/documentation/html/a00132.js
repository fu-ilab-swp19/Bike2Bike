var a00132 =
[
    [ "buffer_size", "a00132.html#a073ad721691e89709e99766f1b1f99f4", null ],
    [ "close", "a00132.html#a2cf4d27a0e9b08d153b190b23d657b67", null ],
    [ "cursor", "a00132.html#a866cb0afeb9c5a5e9346013639f3de6a", null ],
    [ "file_size", "a00132.html#a3437d09d3e832ee71525cda61413663a", null ],
    [ "open", "a00132.html#a6afc15d5610b1300cbc0e1e5663ac6f8", null ],
    [ "p_arg", "a00132.html#a0b9b4f4866f994b2aa506d0eebd721e2", null ],
    [ "p_buffer", "a00132.html#a7bbd951320fc7f5dcdaf8da932021034", null ],
    [ "p_callback", "a00132.html#adbf8fed1eb53df72db1ef2f26b4f2416", null ],
    [ "p_filename", "a00132.html#a06d498a827c49c5681fec4be5f4826fa", null ],
    [ "read", "a00132.html#a55a476593e155b895bf9c0e682687817", null ],
    [ "rewind", "a00132.html#ad11bf1c69203cb9d264b6cd29812cad1", null ],
    [ "seek", "a00132.html#a985aaf312dd0bd88074bd2b6884aa533", null ],
    [ "tell", "a00132.html#a9018ac889feef54032d3de9c2656ac2f", null ],
    [ "type", "a00132.html#a00f569f6bba04f7d313c55ab4b0041d3", null ],
    [ "write", "a00132.html#ade66b70977896d379150e2e1c3536749", null ]
];