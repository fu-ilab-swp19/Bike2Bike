var a00120 =
[
    [ "device_rev", "a00120.html#a35291383c3fc311def52bf828fc99386", null ],
    [ "device_type", "a00120.html#a1a77c3ef129c3527681c089fce4b95a5", null ]
];